#ifndef BOUNDED_BUFFER_ITERATOR_SUITE_H_
#define BOUNDED_BUFFER_ITERATOR_SUITE_H_

#include "cute_suite.h"

extern cute::suite make_suite_bounded_buffer_iterator_suite();

#endif
